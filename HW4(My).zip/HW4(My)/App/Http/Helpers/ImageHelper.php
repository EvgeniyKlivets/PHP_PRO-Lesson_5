<?php
namespace   App\Http\Helpers;

class ImageHelper
{
    public function __construct()
    {
        echo __CLASS__;
    }
}