<?php
namespace  App\Http\Controllers;

class MainController
{
    public function __construct()
    {
    echo __CLASS__;
    }
}