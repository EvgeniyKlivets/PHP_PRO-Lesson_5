<?php
namespace   App\Http\Controllers\Admin;

class DashboardController
{
    public function __construct()
    {
        echo __CLASS__;
    }
}