<?php

namespace App\Http\Controllers\Admin;

class OrdersControllers

{
    public function __construct()
    {
        echo __CLASS__;
    }
}
