<?php
//namespace App\Models;
namespace Models;

class User
{
    public function __construct(){
        echo __CLASS__;
    }
}