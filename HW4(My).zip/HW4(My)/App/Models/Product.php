<?php
//namespace App\Models;
namespace Models;

class Product
{
    public function __construct(){
        echo __CLASS__;
    }
}